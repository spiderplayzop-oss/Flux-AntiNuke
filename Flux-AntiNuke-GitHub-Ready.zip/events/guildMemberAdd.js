const { Events } = require("discord.js");
const { getGuild, protect, AuditLogEvent } = require("../utils/security");
module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member) {
    if (!member.user.bot) return;
    const s = getGuild(member.guild.id);
    await protect({ guild: member.guild, action: "botAdd", limit: s.limits.botAdd, targetId: member.id, auditType: AuditLogEvent.BotAdd, description: `Bot added: ${member.user.tag}` });
  }
};