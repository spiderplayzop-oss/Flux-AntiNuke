require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  Partials,
  Collection,
  REST,
  Routes
} = require("discord.js");
const fs = require("fs");
const path = require("path");

if (!process.env.DISCORD_TOKEN || process.env.DISCORD_TOKEN === "PUT_YOUR_BOT_TOKEN_HERE") {
  console.error("Missing DISCORD_TOKEN. Create a .env file from .env.example.");
  process.exit(1);
}
if (!process.env.CLIENT_ID || process.env.CLIENT_ID === "PUT_YOUR_APPLICATION_ID_HERE") {
  console.error("Missing CLIENT_ID in .env.");
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration
  ],
  partials: [Partials.GuildMember]
});

client.commands = new Collection();

const commandDir = path.join(__dirname, "commands");
for (const file of fs.readdirSync(commandDir).filter(f => f.endsWith(".js"))) {
  const command = require(path.join(commandDir, file));
  client.commands.set(command.data.name, command);
}

const eventDir = path.join(__dirname, "events");
for (const file of fs.readdirSync(eventDir).filter(f => f.endsWith(".js"))) {
  const event = require(path.join(eventDir, file));
  if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
  else client.on(event.name, (...args) => event.execute(...args, client));
}

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction, client);
  } catch (error) {
    console.error(error);
    const response = { content: "Something went wrong while running that command.", ephemeral: true };
    if (interaction.replied || interaction.deferred) await interaction.followUp(response);
    else await interaction.reply(response);
  }
});

client.once("ready", async () => {
  console.log(`Logged in as ${client.user.tag}`);

  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
  const commands = [...client.commands.values()].map(c => c.data.toJSON());

  try {
    if (process.env.GUILD_ID) {
      await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
        { body: commands }
      );
      console.log("Guild slash commands registered.");
    } else {
      await rest.put(
        Routes.applicationCommands(process.env.CLIENT_ID),
        { body: commands }
      );
      console.log("Global slash commands registered.");
    }
  } catch (error) {
    console.error("Slash-command registration failed:", error);
  }
});

client.login(process.env.DISCORD_TOKEN);
