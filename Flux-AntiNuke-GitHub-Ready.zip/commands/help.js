const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("Show Flux commands"),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle("Flux Security")
      .setDescription("Anti-nuke and server security commands.")
      .addFields(
        { name: "/antinuke", value: "Enable, disable and configure protection." },
        { name: "/whitelist", value: "Manage trusted users." },
        { name: "/security", value: "View current settings." }
      );
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};