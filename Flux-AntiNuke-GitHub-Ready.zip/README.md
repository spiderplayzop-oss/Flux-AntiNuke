# Flux Anti-Nuke — GitHub + Android Ready

## 1. Create your Discord application
Open the Discord Developer Portal and create/open your Flux application.

Copy:
- **Application ID** → `CLIENT_ID`
- **Bot Token** → `DISCORD_TOKEN` (keep this secret)
- Your server ID → `GUILD_ID`

## 2. Upload to GitHub
Create a new GitHub repository and upload all files from this project.

**Do not upload `.env`.**
The included `.gitignore` prevents it from being committed.

## 3. Run on Android with Termux

Install Termux from F-Droid:
https://f-droid.org/packages/com.termux/

Then:

```bash
pkg update
pkg upgrade
pkg install nodejs git
```

Clone your GitHub repository:

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd Flux-AntiNuke-GitHub
npm install
```

Create `.env`:

```bash
cp .env.example .env
```

Edit `.env` and put your values in it.

Start:

```bash
npm start
```

## 4. Discord permissions

The bot needs the permissions required for the features you enable, including:
- View Audit Log
- Manage Roles
- Manage Channels
- Ban Members
- Kick Members

Put the bot's role high enough to manage the roles you want protected.

Do not give Administrator unless you understand the security implications.

## 5. Commands

```text
/help
/security
/antinuke enable
/antinuke disable
/antinuke limit
/antinuke window
/whitelist add
/whitelist remove
/whitelist list
```

## Important

Test on a private server before using it on an important server. This project is a security starter, not a guarantee against every Discord attack. Audit-log timing can occasionally cause an event to be missed or attributed incorrectly.

Never publish your bot token. If it is exposed, regenerate it immediately in the Discord Developer Portal.
