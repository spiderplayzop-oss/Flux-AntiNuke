const { Events } = require("discord.js");
const { getGuild, protect, AuditLogEvent } = require("../utils/security");
module.exports = {
  name: Events.GuildMemberRemove,
  async execute(member) {
    const s = getGuild(member.guild.id);
    await protect({ guild: member.guild, action: "kick", limit: s.limits.kick, targetId: member.id, auditType: AuditLogEvent.MemberKick, description: `Possible kick: ${member.user?.tag || member.id}` });
  }
};