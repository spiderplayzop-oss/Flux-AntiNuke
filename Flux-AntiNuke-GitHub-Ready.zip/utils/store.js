const fs = require("fs");
const path = require("path");
const config = require("../config.json");

const file = path.join(__dirname, "..", "data", "security.json");

function load() {
  if (!fs.existsSync(file)) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify({ guilds: {} }, null, 2));
  }
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function save(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function defaults() {
  return {
    enabled: false,
    whitelist: [],
    windowSeconds: config.defaultWindowSeconds,
    punishment: config.defaultPunishment,
    limits: {
      ban: config.defaultLimit,
      kick: config.defaultLimit,
      channelDelete: 2,
      channelCreate: 4,
      roleDelete: 2,
      roleCreate: 4,
      botAdd: 1
    }
  };
}

function getGuild(guildId) {
  const data = load();
  if (!data.guilds[guildId]) {
    data.guilds[guildId] = defaults();
    save(data);
  }
  return data.guilds[guildId];
}

function updateGuild(guildId, patch) {
  const data = load();
  const current = getGuild(guildId);
  data.guilds[guildId] = { ...current, ...patch };
  save(data);
  return data.guilds[guildId];
}

module.exports = { load, save, getGuild, updateGuild };