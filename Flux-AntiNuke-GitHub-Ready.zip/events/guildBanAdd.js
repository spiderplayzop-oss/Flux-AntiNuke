const { Events } = require("discord.js");
const { getGuild, protect, AuditLogEvent } = require("../utils/security");
module.exports = {
  name: Events.GuildBanAdd,
  async execute(ban) {
    const s = getGuild(ban.guild.id);
    await protect({ guild: ban.guild, action: "ban", limit: s.limits.ban, targetId: ban.user.id, auditType: AuditLogEvent.MemberBanAdd, description: `Member banned: ${ban.user.tag}` });
  }
};