const { Events } = require("discord.js");
const { getGuild, protect, AuditLogEvent } = require("../utils/security");
module.exports = {
  name: Events.RoleCreate,
  async execute(role) {
    const s = getGuild(role.guild.id);
    await protect({ guild: role.guild, action: "roleCreate", limit: s.limits.roleCreate, targetId: role.id, auditType: AuditLogEvent.RoleCreate, description: `Role created: ${role.name}` });
  }
};