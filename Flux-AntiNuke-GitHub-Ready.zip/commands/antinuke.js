const { SlashCommandBuilder } = require("discord.js");
const { getGuild, updateGuild } = require("../utils/store");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("antinuke")
    .setDescription("Configure Anti-Nuke")
    .addSubcommand(s => s.setName("enable").setDescription("Enable protection"))
    .addSubcommand(s => s.setName("disable").setDescription("Disable protection"))
    .addSubcommand(s => s.setName("limit").setDescription("Set an action limit")
      .addStringOption(o => o.setName("action").setDescription("Action").setRequired(true)
        .addChoices(
          { name: "ban", value: "ban" },
          { name: "kick", value: "kick" },
          { name: "channel-delete", value: "channelDelete" },
          { name: "channel-create", value: "channelCreate" },
          { name: "role-delete", value: "roleDelete" },
          { name: "role-create", value: "roleCreate" },
          { name: "bot-add", value: "botAdd" }
        ))
      .addIntegerOption(o => o.setName("amount").setDescription("Allowed actions").setMinValue(1).setMaxValue(20).setRequired(true)))
    .addSubcommand(s => s.setName("window").setDescription("Set detection window")
      .addIntegerOption(o => o.setName("seconds").setDescription("1-60 seconds").setMinValue(1).setMaxValue(60).setRequired(true))),
  async execute(interaction) {
    if (interaction.user.id !== interaction.guild.ownerId)
      return interaction.reply({ content: "Only the server owner can configure Anti-Nuke.", ephemeral: true });

    const s = getGuild(interaction.guildId);
    const sub = interaction.options.getSubcommand();

    if (sub === "enable") {
      updateGuild(interaction.guildId, { enabled: true });
      return interaction.reply({ content: "🛡️ Anti-Nuke enabled.", ephemeral: true });
    }

    if (sub === "disable") {
      updateGuild(interaction.guildId, { enabled: false });
      return interaction.reply({ content: "Anti-Nuke disabled.", ephemeral: true });
    }

    if (sub === "limit") {
      const action = interaction.options.getString("action");
      const amount = interaction.options.getInteger("amount");
      updateGuild(interaction.guildId, { limits: { ...s.limits, [action]: amount } });
      return interaction.reply({ content: `${action} limit set to ${amount}.`, ephemeral: true });
    }

    const seconds = interaction.options.getInteger("seconds");
    updateGuild(interaction.guildId, { windowSeconds: seconds });
    await interaction.reply({ content: `Detection window set to ${seconds}s.`, ephemeral: true });
  }
};