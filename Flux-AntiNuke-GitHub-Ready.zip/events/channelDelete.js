const { Events } = require("discord.js");
const { getGuild, protect, AuditLogEvent } = require("../utils/security");
module.exports = {
  name: Events.ChannelDelete,
  async execute(channel) {
    if (!channel.guild) return;
    const s = getGuild(channel.guild.id);
    await protect({ guild: channel.guild, action: "channelDelete", limit: s.limits.channelDelete, targetId: channel.id, auditType: AuditLogEvent.ChannelDelete, description: `Channel deleted: ${channel.name}` });
  }
};