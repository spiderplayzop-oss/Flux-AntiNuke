const { Events } = require("discord.js");
const { getGuild, protect, AuditLogEvent } = require("../utils/security");
module.exports = {
  name: Events.RoleDelete,
  async execute(role) {
    const s = getGuild(role.guild.id);
    await protect({ guild: role.guild, action: "roleDelete", limit: s.limits.roleDelete, targetId: role.id, auditType: AuditLogEvent.RoleDelete, description: `Role deleted: ${role.name}` });
  }
};