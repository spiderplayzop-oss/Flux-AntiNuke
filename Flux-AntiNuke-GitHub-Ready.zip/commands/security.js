const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { getGuild } = require("../utils/store");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("security")
    .setDescription("View Flux security settings"),
  async execute(interaction) {
    const s = getGuild(interaction.guildId);
    const limits = Object.entries(s.limits).map(([key, value]) => `${key}: ${value}`).join("\n");

    const embed = new EmbedBuilder()
      .setTitle("🛡️ Flux Security")
      .addFields(
        { name: "Status", value: s.enabled ? "Enabled" : "Disabled", inline: true },
        { name: "Window", value: `${s.windowSeconds}s`, inline: true },
        { name: "Punishment", value: s.punishment, inline: true },
        { name: "Limits", value: limits },
        { name: "Whitelist", value: s.whitelist.length ? s.whitelist.map(id => `<@${id}>`).join(", ") : "None" }
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};