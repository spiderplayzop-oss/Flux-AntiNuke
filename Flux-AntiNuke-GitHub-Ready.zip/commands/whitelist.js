const { SlashCommandBuilder } = require("discord.js");
const { getGuild, updateGuild } = require("../utils/store");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("whitelist")
    .setDescription("Manage trusted users")
    .addSubcommand(s => s.setName("add").setDescription("Whitelist a user")
      .addUserOption(o => o.setName("user").setDescription("User").setRequired(true)))
    .addSubcommand(s => s.setName("remove").setDescription("Remove a user")
      .addUserOption(o => o.setName("user").setDescription("User").setRequired(true)))
    .addSubcommand(s => s.setName("list").setDescription("Show whitelist")),
  async execute(interaction) {
    if (interaction.user.id !== interaction.guild.ownerId)
      return interaction.reply({ content: "Only the server owner can manage the whitelist.", ephemeral: true });

    const s = getGuild(interaction.guildId);
    const sub = interaction.options.getSubcommand();

    if (sub === "list")
      return interaction.reply({ content: s.whitelist.length ? s.whitelist.map(id => `<@${id}>`).join("\n") : "Whitelist is empty.", ephemeral: true });

    const user = interaction.options.getUser("user");
    let list = [...s.whitelist];

    if (sub === "add") {
      if (!list.includes(user.id)) list.push(user.id);
      updateGuild(interaction.guildId, { whitelist: list });
      return interaction.reply({ content: `Added ${user.tag}.`, ephemeral: true });
    }

    list = list.filter(id => id !== user.id);
    updateGuild(interaction.guildId, { whitelist: list });
    return interaction.reply({ content: `Removed ${user.tag}.`, ephemeral: true });
  }
};