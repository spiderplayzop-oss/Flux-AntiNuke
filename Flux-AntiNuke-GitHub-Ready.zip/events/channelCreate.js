const { Events } = require("discord.js");
const { getGuild, protect, AuditLogEvent } = require("../utils/security");
module.exports = {
  name: Events.ChannelCreate,
  async execute(channel) {
    if (!channel.guild) return;
    const s = getGuild(channel.guild.id);
    await protect({ guild: channel.guild, action: "channelCreate", limit: s.limits.channelCreate, targetId: channel.id, auditType: AuditLogEvent.ChannelCreate, description: `Channel created: ${channel.name}` });
  }
};