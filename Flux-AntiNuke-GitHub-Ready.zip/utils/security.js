const { AuditLogEvent } = require("discord.js");
const { getGuild } = require("./store");

const buckets = new Map();

function isWhitelisted(guildId, userId) {
  return getGuild(guildId).whitelist.includes(userId);
}

function record(guildId, userId, action, limit, windowSeconds) {
  const key = `${guildId}:${userId}:${action}`;
  const now = Date.now();
  const previous = buckets.get(key) || [];
  const recent = previous.filter(t => now - t < windowSeconds * 1000);
  recent.push(now);
  buckets.set(key, recent);
  return { count: recent.length, triggered: recent.length >= limit };
}

async function findExecutor(guild, auditType, targetId) {
  try {
    const logs = await guild.fetchAuditLogs({ type: auditType, limit: 10 });
    const entry = logs.entries.find(entry =>
      entry.target?.id === targetId &&
      Date.now() - entry.createdTimestamp < 10000
    );
    return entry?.executor || null;
  } catch {
    return null;
  }
}

async function stripRoles(guild, userId, reason) {
  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member || member.id === guild.ownerId) return false;

  try {
    const removable = member.roles.cache.filter(role => role.editable && role.id !== guild.id);
    if (!removable.size) return false;
    await member.roles.remove(removable, reason);
    return true;
  } catch (error) {
    console.error("Role stripping failed:", error.message);
    return false;
  }
}

async function logSecurity(guild, message) {
  if (!process.env.LOG_CHANNEL_ID) return;
  const channel = guild.channels.cache.get(process.env.LOG_CHANNEL_ID);
  if (channel?.isTextBased()) {
    await channel.send(`🛡️ ${message}`).catch(() => {});
  }
}

async function protect({ guild, action, limit, targetId, auditType, description }) {
  const settings = getGuild(guild.id);
  if (!settings.enabled) return;

  const executor = await findExecutor(guild, auditType, targetId);
  if (!executor) return;
  if (executor.bot || executor.id === guild.ownerId) return;
  if (isWhitelisted(guild.id, executor.id)) return;

  const result = record(
    guild.id,
    executor.id,
    action,
    limit,
    settings.windowSeconds
  );

  await logSecurity(
    guild,
    `${description} | Executor: ${executor.tag} | ${result.count}/${limit}`
  );

  if (result.triggered) {
    const success = await stripRoles(
      guild,
      executor.id,
      `Flux Anti-Nuke: ${description}`
    );

    await logSecurity(
      guild,
      `🚨 Threshold reached for ${executor.tag}. ${success ? "Roles stripped." : "Could not strip roles."}`
    );
  }
}

module.exports = { AuditLogEvent, getGuild, updateGuild: require("./store").updateGuild, isWhitelisted, protect, logSecurity };